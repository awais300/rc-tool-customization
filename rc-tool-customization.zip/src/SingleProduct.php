<?php

namespace EWA\RCTool;

use EWA\RCTool\Admin\Product\LeadTime;
use EWA\RCTool\Admin\Settings;
use WC_Product;

defined('ABSPATH') || exit;

/**
 * Class SingleProduct
 * Handles single product display customization.
 *
 * @package EWA\RCTool
 */
class SingleProduct
{
    /**
     * Construct the class.
     */
    public function __construct()
    {
        add_action('woocommerce_before_add_to_cart_form', array($this, 'display_lead_time_message'));
        add_filter('woocommerce_product_single_add_to_cart_text', array($this, 'custom_add_to_cart_text'), 10, 2);
    }

    /**
     * Display the lead time message.
     *
     * @return void
     * @throws \Exception If the product is not a WooCommerce product.
     */
    public function display_lead_time_message()
    {
        global $post;
        if (!is_product() || empty($post)) {
            return;
        }

        $product = wc_get_product(get_the_ID());
        if (!is_a($product, 'WC_Product')) {
            throw new \Exception(__('Not a WooCommerce product', 'rct-customization'));
        }

        $lead_time_message = !empty($product->get_meta(LeadTime::PRODUCT_LEAD_TIME_FIELD)) ? $product->get_meta(LeadTime::PRODUCT_LEAD_TIME_FIELD) : get_option(Settings::GLOBAL_LEAD_TIME_FIELD);

        if (!empty($lead_time_message)) {
            echo '<div class="rct-lead-time-message rct-woocommerce-store-notice">';
            echo '<h5><i class="fa fa-truck" aria-hidden="true"></i> Lead Time</h5>';
            echo '<p>' . $lead_time_message . '</p>';
            echo '</div>';
        }
    }

    /**
     * Add custom text for add to cart button.
     *
     * @param string $add_to_cart_text The original text.
     * @param WC_Product $product The WooCommerce product.
     * @return string The modified text.
     */
    public function custom_add_to_cart_text($add_to_cart_text, $product)
    {
        if (is_admin()) {
            return;
        }

        if (!(Helper::get_instance())->is_distributor()) {
            return __('Add to RFQ', 'rct-customization');
        }

        return $add_to_cart_text;
    }
}

add_action('acf/include_fields', function () {
    if (!function_exists('acf_add_local_field_group')) {
        return;
    }

    acf_add_local_field_group(array(
        'key' => 'group_661d891f31a4f',
        'title' => 'Pricing Levels',
        'fields' => array(
            array(
                'key' => 'field_661d9fededa80',
                'label' => 'Important!',
                'name' => '',
                'aria-label' => '',
                'type' => 'message',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'message' => 'Please refrain from changing anything within this section. This area is utilized for development purposes and for creating logical constructs within the code. Modifying the contents below may lead to unforeseen outcomes or errors.',
                'new_lines' => 'wpautop',
                'esc_html' => 0,
            ),
            array(
                'key' => 'field_661d8d07d3322',
                'label' => 'Historical Pricing',
                'name' => '',
                'aria-label' => '',
                'type' => 'tab',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'placement' => 'top',
                'endpoint' => 0,
            ),
            array(
                'key' => 'field_661d8920a8c4d',
                'label' => 'Price Break Levels',
                'name' => 'price_break_levels',
                'aria-label' => '',
                'type' => 'repeater',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'layout' => 'table',
                'pagination' => 0,
                'min' => 0,
                'max' => 9,
                'collapsed' => '',
                'button_label' => 'Add Row',
                'rows_per_page' => 20,
                'sub_fields' => array(
                    array(
                        'key' => 'field_661d8c07a8c4e',
                        'label' => 'Series',
                        'name' => 'series',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8920a8c4d',
                    ),
                    array(
                        'key' => 'field_661d8c19a8c4f',
                        'label' => 'Level1',
                        'name' => 'level1',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8920a8c4d',
                    ),
                    array(
                        'key' => 'field_661d8c38a8c50',
                        'label' => 'Level2',
                        'name' => 'level2',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8920a8c4d',
                    ),
                    array(
                        'key' => 'field_661d8c47a8c51',
                        'label' => 'Level3',
                        'name' => 'level3',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8920a8c4d',
                    ),
                    array(
                        'key' => 'field_661d8c54a8c52',
                        'label' => 'Level4',
                        'name' => 'level4',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8920a8c4d',
                    ),
                ),
            ),
            array(
                'key' => 'field_661d95502b634',
                'label' => 'Quantity Pricing',
                'name' => '',
                'aria-label' => '',
                'type' => 'tab',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'placement' => 'top',
                'endpoint' => 0,
            ),
            array(
                'key' => 'field_661d8d7d2d5e9',
                'label' => 'Quantity Purchased Levels',
                'name' => 'qty_purchased_levels',
                'aria-label' => '',
                'type' => 'repeater',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'layout' => 'table',
                'pagination' => 0,
                'min' => 0,
                'max' => 10,
                'collapsed' => '',
                'button_label' => 'Add Row',
                'rows_per_page' => 20,
                'sub_fields' => array(
                    array(
                        'key' => 'field_661d8d7d2d5ea',
                        'label' => 'Series',
                        'name' => 'series',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8d7d2d5e9',
                    ),
                    array(
                        'key' => 'field_661d8d7d2d5eb',
                        'label' => 'Level1',
                        'name' => 'level1',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8d7d2d5e9',
                    ),
                    array(
                        'key' => 'field_661d8d7d2d5ec',
                        'label' => 'Level2',
                        'name' => 'level2',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8d7d2d5e9',
                    ),
                    array(
                        'key' => 'field_661d8d7d2d5ed',
                        'label' => 'Level3',
                        'name' => 'level3',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8d7d2d5e9',
                    ),
                    array(
                        'key' => 'field_661d8d7d2d5ee',
                        'label' => 'Level4',
                        'name' => 'level4',
                        'aria-label' => '',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_661d8d7d2d5e9',
                    ),
                ),
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'options_page',
                    'operator' => '==',
                    'value' => 'pricing-levels',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
        'description' => '',
        'show_in_rest' => 0,
    ));
});
